use strict;
use warnings;

# this test was generated with Dist::Zilla::Plugin::Test::EOL 0.19

use Test::More 0.88;
use Test::EOL;

my @files = (
    'bin/perlmf',
    'lib/Module/Format.pm',
    'lib/Module/Format/Module.pm',
    'lib/Module/Format/ModuleList.pm',
    'lib/Module/Format/PerlMF_App.pm',
    't/00-compile.t',
    't/00-load.t',
    't/module-list.t',
    't/module.t',
    't/perlmf-app.t'
);

eol_unix_ok($_, { trailing_whitespace => 1 }) foreach @files;
done_testing;
