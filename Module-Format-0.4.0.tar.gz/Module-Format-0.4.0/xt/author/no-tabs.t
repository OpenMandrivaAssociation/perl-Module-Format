use strict;
use warnings;

# this test was generated with Dist::Zilla::Plugin::Test::NoTabs 0.15

use Test::More 0.88;
use Test::NoTabs;

my @files = (
    'bin/perlmf',
    'lib/Module/Format.pm',
    'lib/Module/Format/Module.pm',
    'lib/Module/Format/ModuleList.pm',
    'lib/Module/Format/PerlMF_App.pm',
    't/00-compile.t',
    't/00-load.t',
    't/module-list.t',
    't/module.t',
    't/perlmf-app.t'
);

notabs_ok($_) foreach @files;
done_testing;
